class NonZero(ValueError):
    pass

class TermuxAPINotInstalled(Exception):
    pass

class TermuxAPIError(Exception):
    pass
