# TODO: do this because i dont have a fingerprint scanner on my phone
class Fingerprint:
    def __init__(self):
        pass
    
    def something(self):
        raise NotImplementedError("coming soon")
