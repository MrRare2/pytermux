class NonZero(ValueError):
    pass

class TermuxAPINotInstallee(Exception):
    pass

class TermuxAPIError(Exception):
    pass
